﻿using System;
using NUnit.Framework;


namespace Eventor_Project.Tests
{
    [TestFixture]
    public class UnitTest1
    {
        [Test]
        public void Register_GetView_ItsOkViewModelIsUserView()
        {
            Console.WriteLine("=====INIT======");
            Console.WriteLine("======ACT======");
            Console.WriteLine("====ASSERT=====");
            Assert.IsFalse(false);
        }

    }
}
