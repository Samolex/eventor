﻿using Eventor_Project.Models.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;

namespace Eventor_Project.Tests.Mock
{
    public partial class MockRepository
    {
        public List<User> Users { get; set; }

        public void GenerateUsers()
        {
            Users = new List<User>();

            var admin = new User()
            {
                UserId = 1,
                Email = "admin",
                Name = "",
                Surname = "",
            };

            var role = Roles.First(p => p.Code == "admin");
            var userRole = new UserRole()
            {
                User = admin,
                UserId = admin.UserId,
                Role = role,
                RoleId = role.RoleId
            };

            admin.Roles =
                new List<UserRole>() {
                    userRole
                };
            Users.Add(admin);

            this.Setup(p => p.Users).Returns(Users.AsQueryable());
            this.Setup(p => p.GetUser(It.IsAny<string>())).Returns((string email) =>
                Users.FirstOrDefault(p => string.Compare(p.Email, email, 0) == 0));
            this.Setup(p => p.Login(It.IsAny<string>(), It.IsAny<string>())).Returns((string email, string password) =>
                       Users.FirstOrDefault(p => string.Compare(p.Email, email, 0) == 0));
        }
    }
}
