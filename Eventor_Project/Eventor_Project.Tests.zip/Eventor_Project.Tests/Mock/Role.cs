﻿using Eventor_Project.Models.User;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Eventor_Project.Tests.Mock
{
    public partial class MockRepository
    {
        public List<Role> Roles { get; set; }

        public void GenerateRoles()
        {
            Roles = new List<Role>();
            Roles.Add(new Role()
            {
                RoleId = 1,
                Code = "admin",
                Name = "Administrator"
            });
            this.Setup(p => p.Roles).Returns(Roles.AsQueryable());
        }
    }
}
