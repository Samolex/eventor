﻿using System;
using NUnit.Framework;
using Ninject;
using System.Web.Mvc;

namespace Eventor_Project.Tests
{
    [SetUpFixture]
    public class UnitTestSetupFixture
    {
        [SetUp]
        public void SetUp()
        {
            InitKernel();
        }

        protected virtual IKernel InitKernel()
        {
            var kernel = new StandardKernel();
            DependencyResolver.SetResolver(new NinjectDependencyResolver(kernel));
            InitRepository(kernel);
            return kernel;
        }


        [TearDown]
        public void TearDown()
        {

        }
    }

}
